<?php
    $conn = mysqli_connect("localhost", "root", "","online_voting_system");
?>
