<?php
    include("vote_panel.php");
?>
