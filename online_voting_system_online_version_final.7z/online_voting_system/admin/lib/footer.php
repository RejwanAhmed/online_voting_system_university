
</div>
</div>

<!-- jQuery CDN - Slim version (=without AJAX) -->
<script src="js/jquery-3.3.1.slim.min.js"></script>

<script type="text/javascript">
    $(document).ready(function() {
        $('#sidebarCollapse').on('click', function() {
            $('#sidebar').toggleClass('active');
        });
    });
</script>
</body>
</html>
